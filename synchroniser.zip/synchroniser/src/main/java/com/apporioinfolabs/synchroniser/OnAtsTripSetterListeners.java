package com.apporioinfolabs.synchroniser;

public interface OnAtsTripSetterListeners {
    void onTripSetSuccess(String message);
    void onTripSetFail(String message);
}
