package com.apporioinfolabs.synchroniser;

public interface OnAtsEmissionListeners {
    void onSuccess(String message);
    void onFailed(String message);
}
