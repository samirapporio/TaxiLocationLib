package com.apporioinfolabs.synchroniser;

import android.provider.Settings;
import android.util.Log;

import org.json.JSONObject;

public class OnStateInfoManager {

    public static String getCurrentPhoeSate() throws Exception{


//        Log.d(""+TAG,"----> "+gson.toJson(getListofRunningServices()));
//
//        JSONObject app_state_jsno = new JSONObject();
//        app_state_jsno.put("location_service_running",isServiceRunning());
//        app_state_jsno.put("running_services", gson.toJson(getListofRunningServices()) );
//        app_state_jsno.put("foreground",app_foreground);
//
//        JSONObject jsonObject = new JSONObject();
//        jsonObject.put("unique_no",""+ Settings.Secure.getString(mContext.getContentResolver(), Settings.Secure.ANDROID_ID));
//        jsonObject.put("package_name",mContext.getApplicationContext().getPackageName());
//        jsonObject.put("permissions",AppInfoManager.getPermissionWithStatus());
//        jsonObject.put("app_state",app_state_jsno);
//
//
//
//
//
//
//
//
//
//
//        return new JSONObject().put("","");
        return "";
    }
}
