package com.apporioinfolabs.synchroniser.handlers;

public interface AtsSocketConnectionHandlers {

    void atsServerConnectionState(boolean value);
}
